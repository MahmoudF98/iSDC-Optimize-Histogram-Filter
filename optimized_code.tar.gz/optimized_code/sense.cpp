#include "headers/sense.h"

using namespace std;

vector< vector <float> > sense(char color, vector< vector <char> > &grid, vector< vector <float> > &beliefs,  float p_hit, float p_miss)
{
    int i, j, height, width;
    height = grid.size();
    width = grid[0].size();
    bool hit;

	for (i = 0; i < height; i++)
	{
		for (j = 0; j < width; j++)
		{
            hit = (color == grid[i][j]);
            beliefs[i][j] = beliefs[i][j] * (hit * p_hit + (1 - hit) * p_miss);
		}
	}
	return beliefs;
}
