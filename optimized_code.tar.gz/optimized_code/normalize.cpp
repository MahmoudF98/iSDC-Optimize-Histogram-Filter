#include "headers/normalize.h"
using namespace std;

vector< vector<float> > normalize(vector< vector <float> > &grid) {

	float total = 0.0;
	int i;
	int j;
    int height = grid.size();
    int width = grid[0].size();

    for (i = 0; i < height; i++)
	{
		for (j=0; j< width; j++)
		{
            total += grid[i][j];
		}
	}

    for (i = 0; i < height; i++)
    {
        for (j=0; j< width; j++)
        {
            grid[i][j] /= total;
        }
    }
	return grid;
}
