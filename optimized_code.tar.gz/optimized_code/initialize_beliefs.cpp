#include "headers/initialize_beliefs.h"

using namespace std;

vector< vector <float> > initialize_beliefs(int height, int width) {

	// initialize variables for new grid
    int area;
    area = height * width;
	vector< vector <float> > newGrid(height, vector< float > (width, 1.0 / ( (float) area)));

	return newGrid;
}