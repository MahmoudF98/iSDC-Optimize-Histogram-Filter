#include "headers/blur.h"

using namespace std;

vector < vector <float> > blur(vector < vector < float> > grid, float blurring) {

		vector < vector <float> > newGrid(grid.size(), vector< float >(grid[0].size(), 0));

    int height = grid.size();
    int width  = grid[0].size();
    float center_prob = 1.0 - blurring;
    float corner_prob = blurring / 12.0;
    float adjacent_prob = blurring / 6.0;
    float grid_val;
    int new_i;
    int new_j;
    float mult;
  	vector < vector <float> > window = {{corner_prob, adjacent_prob, corner_prob},
                                      	{adjacent_prob, center_prob, adjacent_prob},
                                      	{corner_prob, adjacent_prob, corner_prob}};
  
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            grid_val = grid[i][j];
            for (int dx = -1; dx < 2; dx++)
            {
                for (int dy = -1; dy < 2; dy++)
                {
                    mult = window[dx+1][dy+1];
                    new_i = (i + dx + height) % height;
                    new_j = (j + dy + width) % width;
                    newGrid[new_i][new_j] += mult * grid_val;
                }
            }
        }
    }
	return newGrid;
}
